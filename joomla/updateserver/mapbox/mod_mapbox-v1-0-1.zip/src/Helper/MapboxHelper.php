<?php

namespace Pablop76\Module\Mapbox\Site\Helper;

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;

class MapboxHelper
{
    public static function getLoggedonUsername(string $default)
    {
        // $user = Factory::getApplication()->getIdentity();
        
        // if ($user->id !== 0) {
        //     // found a logged-on user
        //     return $user->username;
        // }
        
        // return $default;
    }
}
